﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttribDemo
{
    [CodeReview("B Class", "14.6.2016", false)]
    public class B
    {
    }
}
