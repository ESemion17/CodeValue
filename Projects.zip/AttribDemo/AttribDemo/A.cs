﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttribDemo
{
    [CodeReview("A Class", "15.7.2016", true)]
    public class A
    {
    }
}
