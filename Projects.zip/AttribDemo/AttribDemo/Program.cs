﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace AttribDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            AnalayzeAssembly(Assembly.GetExecutingAssembly());

            //AnalayzeAssembly(Assembly.LoadFrom(@"C:\Users\Semion\Documents\visual studio 2015\Projects\DynInvoke\DynInvoke\bin\Debug\DynInvoke.exe"));
            //OR better
            //AnalayzeAssembly(Assembly.LoadFrom(@"..\..\..\..\DynInvoke\DynInvoke\bin\Debug\DynInvoke.exe"));
            //It did nothing because this assembly file not contain CodeReviewAttribute on any type
        }

        static bool AnalayzeAssembly(Assembly assembly)
        {
            bool flag = true;
            foreach (var type in assembly.GetTypes())
                Console.WriteLine(type + "\t\t==>\t\t"+type.IsDefined(typeof(CodeReviewAttribute)));
                //if (type.IsDefined(typeof(CodeReviewAttribute)))
                //{
                //    var att = (CodeReviewAttribute)Attribute.GetCustomAttribute(type, typeof(CodeReviewAttribute));
                //    Console.WriteLine("Name: " + att.Name);
                //    Console.WriteLine("Date: " + att.Data);
                //    Console.WriteLine("Is Code Approved: " + att.CodeApproved);
                //    flag &= att.CodeApproved;
                //}
            return flag;
        }
    }
}
