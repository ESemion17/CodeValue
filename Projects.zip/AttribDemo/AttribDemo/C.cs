﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttribDemo
{
    [CodeReview("C Class", "13.5.2016", true)]
    public class C
    {
    }
}
