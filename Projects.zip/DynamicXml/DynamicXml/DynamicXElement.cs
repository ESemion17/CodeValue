﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DynamicXml
{
    class DynamicXElement: DynamicObject
    {
        private readonly XElement _element;



        private DynamicXElement(XElement xElement)
        {
            _element = xElement;
        }
    }
}




