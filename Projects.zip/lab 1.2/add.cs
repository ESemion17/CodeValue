class Calc
{
	static int Add(int a, int b)
	{
		return a+b;
	}
}